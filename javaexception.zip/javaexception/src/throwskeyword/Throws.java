package throwskeyword;

import java.io.IOException;

public class Throws {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo t =new Demo();
		try {
			t.display();
		}
		catch (IOException e) {
			System.out.println(e);
		}
	}
}
