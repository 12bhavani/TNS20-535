package throwskeyword;
import java.io.IOException;
public class Demo {
	static void display()throws IOException
	{
		throw new IOException();
	}
}
