package finallykeyword;

public class Finally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("welcome");
			}
		catch(Exception e)
			{
			System.out.println("hi");
			}
		finally {
			 System.out.println("hello java");
			}
	}

}
