package exception2;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Division.divide();
	}

}
