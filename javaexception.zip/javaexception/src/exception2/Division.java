package exception2;

public class Division {
	public static void divide()
	{
		int a=6, b=0, c;
		try {
			c=a/b;
		}
		catch(ArithmeticException e ) {
			System.out.println(e.getMessage());
		}
	}
}
