package exception;

public class Exceptn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int d=9;
		try {
			int s = 9/0;
			}
		catch(ArithmeticException e ) {
			System.out.println(e.getMessage());
			}
	}
}
