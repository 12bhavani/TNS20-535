package com.placementmgmt.service.com;

import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.placementmgmt.demo.Certificate;
import com.placementmgmt.repository.demo.CertificateRepository;

@Service
public class ServiceImp implements CertificateService{
	CertificateRepository certificateRepository;

	@Override
	public Certificate saveCertificate(Certificate certificate) {
		// TODO Auto-generated method stub
		return certificateRepository.save(certificate);
	}

	@Override
	public List<Certificate> fetchCertificateList() {
		// TODO Auto-generated method stub
		return certificateRepository.findAll();
	}

	@Override
	public Certificate fetchCertificateById(Long certificateId) {
		// TODO Auto-generated method stub
		return certificateRepository.findById(certificateId).get();
	}

	@Override
	public void deleteCertificateById(Long certificateId) {
		// TODO Auto-generated method stub
		certificateRepository.deleteById(certificateId);
	}

	@Override
	public Certificate updateCertificate(Long certificateId, Certificate certificate) {
		// TODO Auto-generated method stub

	if(Objects.nonNull(certificate.getYear()) &&
       !"".equals(certificate.getYear())) {
		updateCertificate(certificateId, certificate).setYear(certificate.getYear());
       }
   
     if(Objects.nonNull(certificate.getCollege()) &&
        !"".equalsIgnoreCase(certificate.getCollege())) {
    	 	updateCertificate(certificateId, certificate).setCollege(certificate.getCollege());
       }
       return certificateRepository.save(updateCertificate(certificateId, certificate));
		
	}
}
