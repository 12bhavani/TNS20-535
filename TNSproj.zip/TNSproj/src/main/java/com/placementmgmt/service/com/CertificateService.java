package com.placementmgmt.service.com;

import java.util.List;

import org.springframework.stereotype.Service;

import com.placementmgmt.demo.Certificate;

@Service
public interface CertificateService {
	Certificate saveCertificate(Certificate certificate);

	List<Certificate> fetchCertificateList();

	Certificate fetchCertificateById(Long certificateId);

	void deleteCertificateById(Long certificateId);

	Certificate updateCertificate(Long certificateId, Certificate certificate);
}
